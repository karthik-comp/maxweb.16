const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
$$('img.logo').forEach(i=>i.src='logo.png');
const wa=t=>'https://wa.me/918106257124?text='+encodeURIComponent(t);
$('#heroWa').href=wa('Hi MAXWEB, I want a website.');$('#priceWa').href=wa('Hi MAXWEB, please send me a quote for a website.');$('#wa2').href=wa('Hi MAXWEB, I was chatting with Priya.');
let tt;function toast(t){const e=$('#toast');e.textContent=t;e.hidden=false;clearTimeout(tt);tt=setTimeout(()=>e.hidden=true,4000)}
function route(){const l=location.hash==='#login';$('#login').hidden=!l;$('#site').hidden=l;$('#fab').hidden=l;if(l){$('#chat').hidden=true;scrollTo(0,0);$('#step1').hidden=false;$('#step2').hidden=true;$('#err').textContent=''}}
addEventListener('hashchange',route);route();
/* 3D tilt */
$$('.tilt').forEach(c=>{c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();c.style.setProperty('--ry',((e.clientX-r.left)/r.width-.5)*12+'deg');c.style.setProperty('--rx',(.5-(e.clientY-r.top)/r.height)*12+'deg')});c.addEventListener('pointerleave',()=>{c.style.setProperty('--rx','0deg');c.style.setProperty('--ry','0deg')})});
const st=$('#stage');st.addEventListener('pointermove',e=>{const r=st.getBoundingClientRect();st.style.setProperty('--ry',((e.clientX-r.left)/r.width-.5)*44+'deg');st.style.setProperty('--rx',(.5-(e.clientY-r.top)/r.height)*28+'deg')});
/* contact form to WhatsApp */
$('#cform').onsubmit=e=>{e.preventDefault();open(wa('Hi MAXWEB, I am '+$('#cn').value+'. '+$('#cm').value),'_blank')};
/* extra motion */
const cur=$('#cur');let px=0,py=0,qx=0,qy=0;
addEventListener('pointermove',e=>{if(e.pointerType!=='mouse')return;qx=e.clientX;qy=e.clientY;cur.style.opacity=1;cur.classList.toggle('h',!!e.target.closest('a,button,.card,input,textarea'))});
(function f(){px+=(qx-px)*.18;py+=(qy-py)*.18;cur.style.transform='translate('+px+'px,'+py+'px)';requestAnimationFrame(f)})();
$$('.card').forEach(c=>c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();c.style.setProperty('--mx',e.clientX-r.left+'px');c.style.setProperty('--my',e.clientY-r.top+'px')}));
const RW=['fast','private','beautiful','secure','easy to use'];let wi=0;
setInterval(()=>{const r=$('#rw');wi=(wi+1)%RW.length;r.textContent=RW[wi];r.style.animation='none';void r.offsetWidth;r.style.animation=''},2200);
document.addEventListener('click',e=>{const b=e.target.closest('.btn');if(!b||b.classList.contains('fab'))return;const r=b.getBoundingClientRect(),s=document.createElement('span');s.className='rp';s.style.left=e.clientX-r.left+'px';s.style.top=e.clientY-r.top+'px';b.append(s);setTimeout(()=>s.remove(),650)});
const sp=$('#spot'),bar=$('#bar');
addEventListener('pointermove',e=>{sp.style.transform='translate('+e.clientX+'px,'+e.clientY+'px)'});
addEventListener('scroll',()=>{bar.style.transform='scaleX('+Math.min(1,scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight))+')'},{passive:true});
const h1=$('.hero h1');h1.innerHTML=h1.textContent.split(' ').map((w,i)=>'<span class="w" style="animation-delay:'+(1.6+i*.09)+'s">'+w+'</span>').join(' ');
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
$$('section h2,section .lead,.svc div,.grid,.sec p,.team>div,.pay,form.cf').forEach((e,i)=>{e.classList.add('rv');e.style.transitionDelay=(i%3)*.1+'s';io.observe(e)});
const pr=$('.price');new IntersectionObserver((es,o)=>{if(es[0].isIntersecting){o.disconnect();const t0=performance.now();(function f(t){const k=Math.min((t-t0)/1400,1),v=Math.round(3000*(1-Math.pow(1-k,3)));pr.textContent='₹'+v.toLocaleString('en-IN');if(k<1)requestAnimationFrame(f)})(t0)}}).observe(pr);
(function(){const c=$('#net'),x=c.getContext('2d'),m={x:-999,y:-999};let W,H,P=[];
function rs(){W=c.width=innerWidth;H=c.height=innerHeight;P=Array.from({length:Math.min(60,Math.floor(W*H/22000))},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35}))}
addEventListener('resize',rs);addEventListener('pointermove',e=>{m.x=e.clientX;m.y=e.clientY});rs();
(function d(){x.clearRect(0,0,W,H);for(const p of P){p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;x.fillStyle='rgba(47,181,174,.55)';x.beginPath();x.arc(p.x,p.y,1.8,0,7);x.fill()}
for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const a=P[i],b=P[j],k=Math.hypot(a.x-b.x,a.y-b.y);if(k<140){x.strokeStyle='rgba(47,181,174,'+(.22*(1-k/140))+')';x.beginPath();x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke()}}
for(const p of P){const k=Math.hypot(p.x-m.x,p.y-m.y);if(k<160){x.strokeStyle='rgba(210,154,104,'+(.5*(1-k/160))+')';x.beginPath();x.moveTo(p.x,p.y);x.lineTo(m.x,m.y);x.stroke()}}
if(!matchMedia('(prefers-reduced-motion:reduce)').matches)requestAnimationFrame(d)})()})();
/* Priya */
const msgs=$('#msgs'),said=[];let voice=false,hi=false;
const KB=[[/pric|cost|rate|rupee|₹|how much|package|plan|quote/,'Our website packages start from ₹3,000. The final price depends on the pages and features you need. Tell me what you want, or tap the WhatsApp button, and the founders will confirm your exact quote.'],
[/warrant|problem|issue|bug|fix|support|maintenance/,'Every website comes with a 1 year free warranty. If anything goes wrong in that year, we fix it at no cost.'],
[/pay|fampay|fam pay|phonepe|phone pe|upi|transaction/,'We accept payments only through FamPay. Once your quote is agreed, you can pay to our FamPay ID 8978957342@fam, shown in the Pricing section.'],
[/secur|privacy|private|safe|data/,'Your privacy matters to us. We use your details only to work on your project, and your chat goes straight to the founders on WhatsApp.'],
[/design|style|theme|logo|brand|look|colour|color|animation|3d/,'We design in your brand colours, with clean layouts and smooth 3D touches. You can open our demo site in the Our work section to see the style.'],
[/contact|whatsapp|number|call|founder|talk|instagram/,'You can reach the founders on WhatsApp at +91 81062 57124 or +91 89789 57342, or on Instagram at maxweb5500.'],
[/^(hi|hello|hey|hii)\b/,'Hello! I am Priya from MAXWEB. Ask me about designs, prices or our warranty.']];
const FEM=/female|woman|zira|hazel|susan|heera|neerja|veena|kalpana|swara|samantha|victoria|karen|moira|tessa|fiona|serena|aria|jenny|sonia|libby|michelle|ava|allison|nicky|google us english/i,MAL=/\bmale\b|david|mark|george|ravi|hemant|prabhat|james|daniel|alex|fred|guy|rishi|thomas|richard|ryan|eric|christopher|ralph|junior/i;
function pick(){const en=speechSynthesis.getVoices().filter(x=>/^en/i.test(x.lang)),ok=x=>FEM.test(x.name)&&!MAL.test(x.name);return en.find(x=>/en[-_]IN/i.test(x.lang)&&ok(x))||en.find(ok)||null}
function speak(t){if(!voice||!('speechSynthesis' in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t),f=pick();if(f){u.voice=f;u.pitch=1.1}else{const e=speechSynthesis.getVoices().find(x=>/^en/i.test(x.lang)&&!MAL.test(x.name));if(e)u.voice=e;u.lang='en-IN';u.pitch=1.7}u.rate=.97;speechSynthesis.speak(u)}
if('speechSynthesis' in window){speechSynthesis.getVoices();speechSynthesis.onvoiceschanged=()=>speechSynthesis.getVoices()}
function add(t,w){const d=document.createElement('div');d.className='m '+w;d.textContent=t;msgs.append(d);msgs.scrollTop=msgs.scrollHeight;if(w==='b')speak(t)}
function ask(q){add(q,'u');said.push(q);$('#wa2').href=wa('Hi MAXWEB, I was chatting with Priya. '+said.join(' | '));const r=KB.find(k=>k[0].test(q.toLowerCase()));const ty=document.createElement('div');ty.className='m b ty';ty.innerHTML='<i></i><i></i><i></i>';msgs.append(ty);msgs.scrollTop=msgs.scrollHeight;setTimeout(()=>{ty.remove();add(r?r[1]:'Thanks for asking! The founders can answer this best. Tap Continue on WhatsApp and your questions will go to them directly.','b')},900)}
function openChat(){$('#chat').hidden=false;$('#fab').hidden=true;if(!hi){hi=true;add('Hello, I am Priya from MAXWEB. Website packages start at ₹3,000 and include a 1 year free warranty. How can I help you?','b')}}
$('#fab').onclick=openChat;$('#cx').onclick=()=>{$('#chat').hidden=true;$('#fab').hidden=false;speechSynthesis&&speechSynthesis.cancel()};
$('#callP').onclick=()=>{voice=true;$('#vo').textContent='🔊';openChat();speak('Hello, I am Priya from MAXWEB. How can I help you?')};
$('#vo').onclick=()=>{voice=!voice;$('#vo').textContent=voice?'🔊':'🔇';if(!voice&&window.speechSynthesis)speechSynthesis.cancel()};
$('#cf').onsubmit=e=>{e.preventDefault();const v=$('#ci').value.trim();if(v){$('#ci').value='';ask(v)}};
$$('.chips button').forEach(b=>b.onclick=()=>ask(b.textContent));
$('#cp').onclick=()=>{const t=$('#upi').textContent;(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>toast('FamPay ID copied'),()=>toast('Copy this ID: '+t))};
/* Login (front-end preview: no server yet) */
$$('[data-p]').forEach(b=>b.onclick=()=>toast(b.dataset.p+' will work once the client portal goes live.'));
$('#ca').onclick=e=>{e.preventDefault();toast('Accounts open with the client portal. For now, message us on WhatsApp.')};
$('#eye').onclick=()=>{const s=$('#pw').type==='password';$('#pw').type=s?'text':'password';$('#eye').textContent=s?'Hide':'Show'};
const reset=e=>{e.preventDefault();toast(/^\S+@\S+\.\S+$/.test($('#em').value)?'We would send a reset link to '+$('#em').value:'Enter your email first, then tap Forgot password.')};
$('#fg').onclick=reset;
$('#lf').onsubmit=async e=>{e.preventDefault();const err=$('#err'),go=$('#go');err.textContent='';
if(!/^\S+@\S+\.\S+$/.test($('#em').value)){err.textContent='Enter a valid email address.';$('#em').focus();return}
const hx=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode($('#pw').value)))].map(b=>b.toString(16).padStart(2,'0')).join('');
if(hx!=='6f4dda012bc311a18b54d79459a41531c8f408628354974fd717749702093b63'){err.innerHTML='That password is not right. <a href="#" id="rs">Reset it?</a>';$('#rs').onclick=reset;$('#pw').value='';$('#pw').focus();return}
go.classList.add('ld');setTimeout(()=>{go.classList.remove('ld');$('#step1').hidden=true;$('#step2').hidden=false;$('#otp').focus()},1100)};
$('#vf').onclick=()=>{if(/^\d{6}$/.test($('#otp').value)){open(wa('MAXWEB login alert: '+$('#em').value+' logged in on '+new Date().toLocaleString('en-IN')),'_blank');toast('Code accepted. Send the WhatsApp message to confirm your login. This is a preview: sign-in is not connected to a server yet.');$('#otp').value='';location.hash=''}else $('#err2').textContent='Enter all 6 digits of your code.'};
